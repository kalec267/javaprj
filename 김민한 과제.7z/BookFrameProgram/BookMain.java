package BookFrameProgram;

import java.io.IOException;

public class BookMain {
    public static void main(String[] args) throws IOException {
        new BookFrame();
    }
}
