package BookFrameProgram;

import java.awt.*;
import java.awt.event.*;

public class BookFrame extends Frame {
    BookManager bm = new BookManager();

    // ���θ޴� ��ǰ
    Button menuInsertbtn;
    Button menuAllprintbtn;
    Button menuViewbtn;
    Button menuUpdatebtn;
    Button menuDeletebtn;

    // �Է� ��ǰ (������, ����, ISBN ����)
    Label insertTitlelb;
    Label insertAuthorlb;
    Label insertIsbnlb;
    TextField insertTitletf;
    TextField insertAuthortf;
    TextField insertIsbntf;
    Button insertInsertbtn;

    // ��ü ��� ��ǰ
    List listBox;
    Label viewIdlb, viewTitlelb, viewAuthorlb, viewIsbnlb;

    // ã�� ��ǰ
    Label updateTitlelb;
    TextField updateaSearchtf;
    Button updateSearchbtn;
    List updateSearchListBox;

    // ���� ��ǰ
    Label editTitlelb;
    Label editAuthorlb;
    Label editIsbnlb;
    TextField editTitletf;
    TextField editAuthortf;
    TextField editIsbntf;
    Button editbtn;

    // ���� ��ǰ
    Label delTitlelb;
    TextField delTitletf;
    Button delbtn;

    public BookFrame() {
        setTitle("���� ���� ���α׷�1");
        setBounds(0, 0, 400, 700);
        setLayout(new FlowLayout());
        setVisible(true);

        // ������ �ݱ� �̺�Ʈ ó��
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        // ���θ޴� ��ǰ �����
        menuInsertbtn = new Button("add Book");
        menuAllprintbtn = new Button("print all Book");
        menuViewbtn = new Button("search Book");
        menuUpdatebtn = new Button("update Book");
        menuDeletebtn = new Button("delete Book");

        // ��ǰ�� ���� ����
        menuInsertbtn.setPreferredSize(new Dimension(300, 50));
        menuAllprintbtn.setPreferredSize(new Dimension(300, 50));
        menuViewbtn.setPreferredSize(new Dimension(300, 50));
        menuUpdatebtn.setPreferredSize(new Dimension(300, 50));
        menuDeletebtn.setPreferredSize(new Dimension(300, 50));

        // ��ǰ�� �߰��ϱ�
        add(menuInsertbtn);
        add(menuAllprintbtn);
        add(menuViewbtn);
        add(menuUpdatebtn);
        add(menuDeletebtn);

        // insert ��� ��ǰ ���� �� �ʱ�ȭ
        insertTitlelb = new Label("������:");
        insertAuthorlb = new Label("����:");
        insertIsbnlb = new Label("ISBN:");
        insertTitletf = new TextField();
        insertAuthortf = new TextField();
        insertIsbntf = new TextField();
        insertInsertbtn = new Button("input Book");

        insertTitlelb.setVisible(false);
        insertAuthorlb.setVisible(false);
        insertIsbnlb.setVisible(false);
        insertTitletf.setVisible(false);
        insertAuthortf.setVisible(false);
        insertIsbntf.setVisible(false);
        insertInsertbtn.setVisible(false);

        add(insertTitlelb); add(insertTitletf);
        add(insertAuthorlb); add(insertAuthortf);
        add(insertIsbnlb); add(insertIsbntf);
        add(insertInsertbtn);

        insertTitlelb.setPreferredSize(new Dimension(60, 50));
        insertAuthorlb.setAlignment(Label.RIGHT);
        insertTitletf.setColumns(20);
        insertAuthorlb.setPreferredSize(new Dimension(60, 50));
        insertAuthortf.setColumns(20);
        insertIsbnlb.setPreferredSize(new Dimension(60, 50));
        insertIsbntf.setColumns(20);
        insertInsertbtn.setPreferredSize(new Dimension(300, 50));

        // menuInsertbtn �̺�Ʈ ó��
        menuInsertbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(); // ��� ��ǰ �����
                insertTitlelb.setVisible(true);
                insertTitletf.setVisible(true);
                insertAuthorlb.setVisible(true);
                insertAuthortf.setVisible(true);
                insertIsbnlb.setVisible(true);
                insertIsbntf.setVisible(true);
                insertInsertbtn.setVisible(true);

                revalidate();
                repaint();

                insertInsertbtn.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        bm.insert(insertTitletf.getText(),
                                insertAuthortf.getText(),
                                insertIsbntf.getText());
                        insertTitletf.setText("");
                        insertAuthortf.setText("");
                        insertIsbntf.setText("");
                        insertTitletf.setFocusable(true);
                    }
                });
            }
        });

        // ��ü��� ��ǰ ����
        listBox = new List(10);
        listBox.setPreferredSize(new Dimension(500, 0));
        Panel panel = new Panel();
        panel.setLayout(new BorderLayout());
        panel.add(listBox);
        add(panel);
        listBox.setVisible(false);

        // ��ü ����Ʈ ���� ��ư (ButtonFunc�� �����Ǿ� �־�� ��)
        // menuAllprintbtn.addActionListener(new ButtonFunc(this, bm.getList()));

        // �󼼺��� ���̺� ����
        viewIdlb = new Label("id:");
        viewIdlb.setBackground(Color.ORANGE);
        viewIdlb.setPreferredSize(new Dimension(200, 30));
        viewIdlb.setVisible(false);
        add(viewIdlb);

        viewTitlelb = new Label("title:");
        viewTitlelb.setBackground(Color.YELLOW);
        viewTitlelb.setPreferredSize(new Dimension(200, 30));
        viewTitlelb.setVisible(false);
        add(viewTitlelb);

        viewAuthorlb = new Label("author:");
        viewAuthorlb.setBackground(Color.cyan);
        viewAuthorlb.setPreferredSize(new Dimension(200, 30));
        viewAuthorlb.setVisible(false);
        add(viewAuthorlb);

        viewIsbnlb = new Label("isbn:");
        viewIsbnlb.setBackground(Color.LIGHT_GRAY);
        viewIsbnlb.setPreferredSize(new Dimension(200, 30));
        viewIsbnlb.setVisible(false);
        add(viewIsbnlb);

        // ����Ʈ ���� �� �󼼺��� �̺�Ʈ
        listBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                setVisible();
                listBox.setVisible(true);
                viewIdlb.setVisible(true);
                viewTitlelb.setVisible(true);
                viewAuthorlb.setVisible(true);
                viewIsbnlb.setVisible(true);

                int id = Integer.parseInt(listBox.getSelectedItem().split(" ")[0]);
                for (d260122_03_BookProgram_Report.Book b : bm.getList()) {
                    if (b.getId() == id && listBox.getSelectedIndex() != 0) {
                        viewIdlb.setText("id:" + b.getId());
                        viewTitlelb.setText("title:" + b.getAuthor()); // ���� �ʵ� ��Ī�� ���� ���� ����
                        viewAuthorlb.setText("author:" + b.getIsbn());
                        viewIsbnlb.setText("isbn:" + b.getDate());
                    }
                }
                revalidate();
                repaint();
            }
        });

        // ã�� ��ǰ �ʱ�ȭ
        updateTitlelb = new Label("search title: ");
        updateaSearchtf = new TextField(20);
        updateSearchbtn = new Button("search");
        updateSearchListBox = new List();

        updateTitlelb.setVisible(false);
        updateaSearchtf.setVisible(false);
        updateSearchbtn.setVisible(false);
        updateSearchListBox.setVisible(false);

        add(updateTitlelb); add(updateaSearchtf); add(updateSearchbtn); add(updateSearchListBox);

        menuViewbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible();
                updateTitlelb.setVisible(true);
                updateaSearchtf.setVisible(true);
                updateSearchbtn.setVisible(true);
                revalidate();
                repaint();
            }
        });

        updateSearchbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible();
                updateTitlelb.setVisible(true);
                updateaSearchtf.setVisible(true);
                updateSearchbtn.setVisible(true);
                updateSearchListBox.setVisible(true);

                // �˻� ���� (���ڸ����� �˻��ϵ��� �Ŵ����� ����)
                bm.selectByName(updateaSearchtf.getText());

                revalidate();
                repaint();
            }
        });

        // ���� ��ǰ �ʱ�ȭ
        editTitlelb = new Label("edit Title: ");
        editTitletf = new TextField(20);
        editAuthorlb = new Label("edit Author: ");
        editAuthortf = new TextField(20);
        editIsbnlb = new Label("edit Isbn: ");
        editIsbntf = new TextField(20);
        editbtn = new Button("update");

        editTitlelb.setVisible(false); editTitletf.setVisible(false);
        editAuthorlb.setVisible(false); editAuthortf.setVisible(false);
        editIsbnlb.setVisible(false); editIsbntf.setVisible(false);
        editbtn.setVisible(false);

        add(editTitlelb); add(editTitletf); add(editAuthorlb);
        add(editAuthortf); add(editIsbnlb); add(editIsbntf); add(editbtn);

        menuUpdatebtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible();
                editTitlelb.setVisible(true); editTitletf.setVisible(true);
                editAuthorlb.setVisible(true); editAuthortf.setVisible(true);
                editIsbnlb.setVisible(true); editIsbntf.setVisible(true);
                editbtn.setVisible(true);
            }
        });

        // ���� ��ǰ �ʱ�ȭ
        delTitlelb = new Label("������ ������ �Է�");
        delTitletf = new TextField(20);
        delbtn = new Button("����");
        delTitlelb.setVisible(false); delTitletf.setVisible(false); delbtn.setVisible(false);

        add(delTitlelb); add(delTitletf); add(delbtn);

        menuDeletebtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible();
                delTitlelb.setVisible(true);
                delTitletf.setVisible(true);
                delbtn.setVisible(true);
            }
        });

        delbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible();
                new DialogFrame(delbtn); // ���̾�α� ȣ��
            }
        });
    }

    public List getListBox() { return listBox; }
    public void setListBox(List listBox) { this.listBox = listBox; }

    // ��� ��ǰ�� ����� �Լ� (��ȭ��ȣ�ο� ������ �̸�)
    public void setVisible() {
        insertTitlelb.setVisible(false); insertAuthorlb.setVisible(false);
        insertIsbnlb.setVisible(false); insertTitletf.setVisible(false);
        insertAuthortf.setVisible(false); insertIsbntf.setVisible(false);
        insertInsertbtn.setVisible(false);

        viewIdlb.setVisible(false); viewTitlelb.setVisible(false);
        viewAuthorlb.setVisible(false); viewIsbnlb.setVisible(false);
        listBox.setVisible(false);

        updateTitlelb.setVisible(false); updateaSearchtf.setVisible(false);
        updateSearchbtn.setVisible(false); updateSearchListBox.setVisible(false);

        editTitlelb.setVisible(false); editTitletf.setVisible(false);
        editAuthorlb.setVisible(false); editAuthortf.setVisible(false);
        editIsbnlb.setVisible(false); editIsbntf.setVisible(false);
        editbtn.setVisible(false);

        delTitlelb.setVisible(false); delTitletf.setVisible(false);
        delbtn.setVisible(false);
    }
}

// ���̾�α� Ŭ���� (PhonebookFrame�� DialogFrame�� ����)
class DialogFrame extends Frame {
    private Button button;
    private Dialog dialog;

    public DialogFrame(Button button, Button button1) {
        this.button = button1;
        setBounds(100, 100, 450, 300);
        setLayout(new FlowLayout());
        setVisible(true);
        button = new Button("�����ϱ�");
        add(button);
        dialog = new Dialog(this, "�����ϱ�", true);
        dialog.setBounds(100, 100, 450, 300);
        dialog.setVisible(true);
    }

    public DialogFrame(Button button) { this.button = button; }
    public DialogFrame() {}
    public Button getButton() { return button; }
    public Dialog getDialog() { return dialog; }
}