package d260127_Phonebook_Report;

import java.awt.*;
import java.awt.event.*;

public class PhonebookFrame extends Frame {
    PhonebookManager pm = new PhonebookManager();

    //        ���θ޴� ��ǰ
    Button menuInsertbtn;
    Button menuAllprintbtn;
    Button menuViewbtn;
    Button menuUpdatebtn;
    Button menuDeletebtn;

    //        �Է� ��ǰ
    Label insertNamelb;
    Label insertHplb;
    Label insertEmaillb;
    TextField insertNametf;
    TextField insertHptf;
    TextField insertEmailtf;
    Button insertInsertbtn;
    //        ��ü ��� ��ǰ
    List listBox;
    Label viewIdlb, viewNamelb, viewHplb, viewEmaillb;


    //     ã�� ��ǰ
    Label updateNamelb;
    TextField updateaSearchtf;
    Button updateSearchbtn;
    List updateSearchListBox;

    //    ���� ��ǰ
    Label editNamelb;
    Label editHplb;
    Label editEmaillb;

    TextField editNametf;
    TextField editHptf;
    TextField editEmailtf;

    Button editbtn;

    //    ���� ��ǰ
    Label delNamelb;
    TextField delNametf;
    Button delbtn;

    public PhonebookFrame() {
        setTitle("��ȭ��ȣ�� ���α׷�1");
        setBounds(0, 0, 400, 700);
        setLayout(new FlowLayout());
        setVisible(true);
        //������ �ݱ� �̺�Ʈ ó��
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        //���θ޴� ��ǰ �����
        menuInsertbtn = new Button("add Phonebook");
        menuAllprintbtn = new Button("print all Phonebook");
        menuViewbtn = new Button("search Phonebook");
        menuUpdatebtn = new Button("update Phonebook");
        menuDeletebtn = new Button("delete Phonebook");

//         ��ǰ�� ���� ����
        menuInsertbtn.setPreferredSize(new Dimension(300, 50));
        menuAllprintbtn.setPreferredSize(new Dimension(300, 50));
        menuViewbtn.setPreferredSize(new Dimension(300, 50));
        menuUpdatebtn.setPreferredSize(new Dimension(300, 50));
        menuDeletebtn.setPreferredSize(new Dimension(300, 50));
        //��ǰ�� �߰��ϱ�
        add(menuInsertbtn);
        add(menuAllprintbtn);
        add(menuViewbtn);
        add(menuUpdatebtn);
        add(menuDeletebtn);

//        insert ��ɿ� ���� ��ǰ�� ����� add �ؾ���
        insertNamelb = new Label("�̸�:");
        insertHplb = new Label("��ȭ��ȣ:");
        insertEmaillb = new Label("�̸���:");
        insertNametf = new TextField();
        insertHptf = new TextField();
        insertEmailtf = new TextField();
        insertInsertbtn = new Button("input Phonebook");

        insertNamelb.setVisible(false);
        insertHplb.setVisible(false);
        insertEmaillb.setVisible(false);
        insertNametf.setVisible(false);
        insertHptf.setVisible(false);
        insertEmailtf.setVisible(false);
        insertInsertbtn.setVisible(false);

        add(insertNamelb);
        add(insertNametf);
        add(insertHplb);
        add(insertHptf);
        add(insertEmaillb);
        add(insertEmailtf);
        add(insertInsertbtn);

        insertNamelb.setPreferredSize(new Dimension(60, 50));
        insertHplb.setAlignment(Label.RIGHT);
        insertNametf.setColumns(20);
        insertHplb.setPreferredSize(new Dimension(60, 50));
        insertHptf.setColumns(20);
        insertEmaillb.setPreferredSize(new Dimension(60, 50));
        insertEmailtf.setColumns(20);
        insertInsertbtn.setPreferredSize(new Dimension(300, 50));


//        updateNamelb.setPreferredSize(new Dimension(60, 50));
//        updateaSearchtf.setColumns(20);
//        updateSearchbtn.setPreferredSize(new Dimension(300, 50));

        //�߰��� ��ǰ�� ó���ϱ� ���� ��ư �̺�Ʈ �߰�
        menuInsertbtn.addActionListener(new ActionListener() {

            //�Է¿� ���� ��ǰ
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible();
                insertNamelb.setVisible(true);
                insertNametf.setVisible(true);
                insertHplb.setVisible(true);
                insertHptf.setVisible(true);
                insertEmaillb.setVisible(true);
                insertEmailtf.setVisible(true);
                insertInsertbtn.setVisible(true);

                //ȭ���� ���� �׸��� ���ؼ��� 2���� �Լ��� ���� ȣ��
                revalidate();
                repaint();
                //insertbtn�� ������ �� �̺�Ʈó��
                insertInsertbtn.addActionListener(new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) {
                        System.out.println(insertNametf.getText());
                        System.out.println(insertHptf.getText());
                        System.out.println(insertEmailtf.getText());
                        pm.insert(insertNametf.getText(),
                                insertHptf.getText(),
                                insertEmailtf.getText());
                        System.out.println(pm.getList());
                        insertNametf.setText("");
                        insertHptf.setText("");
                        insertEmailtf.setText("");
                        insertNametf.setFocusable(true);
                    }
                });
            }
        });

//        ��ü��� ��ǰ���� �� ����
        listBox = new List(10);
        listBox.setPreferredSize(new Dimension(500, 0));
        Panel panel = new Panel();
        panel.setLayout(new BorderLayout());
        panel.setSize(500, 0);
        panel.add(listBox);

        add(panel);
        listBox.setVisible(false);

//        ��ü ����Ʈ ����
        menuAllprintbtn.addActionListener(new ButtonFunc(this, pm.getList()));

        //�󼼺��� BorderLayout�� south�� ����
        viewIdlb = new Label("id:");
        viewIdlb.setBackground(Color.ORANGE);
        viewIdlb.setPreferredSize(new Dimension(200, 30));
        viewIdlb.setVisible(false);
        add(viewIdlb);

        viewNamelb = new Label("name:");
        viewNamelb.setBackground(Color.YELLOW);
        viewNamelb.setPreferredSize(new Dimension(200, 30));
        viewNamelb.setVisible(false);
        add(viewNamelb);

        viewHplb = new Label("hp:");
        viewHplb.setBackground(Color.cyan);
        viewHplb.setPreferredSize(new Dimension(200, 30));
        viewHplb.setVisible(false);
        add(viewHplb);

        viewEmaillb = new Label("email:");
        viewEmaillb.setBackground(Color.LIGHT_GRAY);
        viewEmaillb.setPreferredSize(new Dimension(200, 30));
        viewEmaillb.setVisible(false);
        add(viewEmaillb);

        //    ��ü ����Ʈ���� �ϳ��� �������� �������� �� �󼼺���
//        listBox.addItemListener(new ButtonFunc(this, pm.getList()));
        /*
         * 1. ����Ʈ�� Ŭ���� ��
         * 2. ����Ʈ�� ������ ������ �� �и�
         * 3. �и��� �����͸� ���̺��� ǥ�� (���̺��� ����, ����, �߰�)*/
        listBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                setVisible();
                listBox.setVisible(true);
                viewIdlb.setVisible(true);
                viewNamelb.setVisible(true);
                viewHplb.setVisible(true);
                viewEmaillb.setVisible(true);

//              �Ʒ��� �����ʹ� �����ӿ��� ����Ʈ�ڽ��� �ִ� �����̹Ƿ� �̸��� Ȯ�� �Ұ�
//                String[] datas = listBox.getSelectedItem().split(" ");

//                listBox���� id�� ���ϰ� ��ü ����Ʈ �������� id�� ���Ͽ� ���� id�� ����Ͻÿ�
                int id = Integer.parseInt(listBox.getSelectedItem().split(" ")[0]);
                for (Phonebook p : pm.getList()) {
                    if (p.getId() == id && listBox.getSelectedIndex() != 0) {
                        System.out.println(p);
                        viewIdlb.setText("id:" + p.getId());
                        viewNamelb.setText("name:" + p.getName());
                        viewHplb.setText("hp:" + p.getHp());
                        viewEmaillb.setText("email:" + p.getEmail());
                    }
                }

                Phonebook p = pm.getList().get((int) e.getItem());


                revalidate();
                repaint();
            }
        });


/*
        1. ã�⿡ �ʿ��� ��ǰ���(�ɹ�����), ����(new), ����(set, ���̺�, ����â, ��ư)
        2. ��ȭ��ȣ�� ã�� ��ư Ŭ������ �� �̺�Ʈ ���(������ ���)
        3. ȭ�鿡 �̸�ã�� â�� ��Ÿ������ ó��(������ �ڵ� ����)
        4. �̸�ã�� ��ư�� Ŭ������ �� ����Ʈ ��� Ȯ��
        5. ����Ʈ�� �����ϸ� �󼼺���
        */
        updateNamelb = new Label("search name: ");
        updateaSearchtf = new TextField(20);
        updateSearchbtn = new Button(("search"));

        updateNamelb.setVisible(false);
        updateaSearchtf.setVisible(false);
        updateSearchbtn.setVisible(false);

        updateSearchListBox = new List();
        updateSearchListBox.setVisible(false);

//        �����ӿ� �߰�
        add(updateNamelb);
        add(updateaSearchtf);
        add(updateSearchbtn);

        add(updateSearchListBox);

        menuViewbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible();
                updateNamelb.setVisible(true);
                updateaSearchtf.setVisible(true);
                updateSearchbtn.setVisible(true);
                revalidate();
                repaint();
            }
        });

//        ã�� ��ư ����
        updateSearchbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                pm.selectByName(updateaSearchtf.getText());

                setVisible();
                updateNamelb.setVisible(true);
                updateaSearchtf.setVisible(true);
                updateSearchbtn.setVisible(true);

                updateSearchListBox.setVisible(true);

                String search = updateaSearchtf.getText();
                Phonebook p = pm.selectByName(search);
                if (p != null) {
                    updateSearchListBox.add(p.getId() + " " + p.getName());
                }

                Button editbtn = new Button("����");
                Button deletebtn = new Button("����");
                Button menubtn = new Button("�޴�");

                editbtn.setVisible(true);
                deletebtn.setVisible(true);
                menubtn.setVisible(true);
                revalidate();
                repaint();
            }
        });

//        �˻��� ����Ʈ �ڽ��� Ŭ������ ��
        updateSearchListBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
//                �󼼺��⸦ ��Ȱ��
                setVisible();
                listBox.setVisible(true);
                viewIdlb.setVisible(true);
                viewNamelb.setVisible(true);
                viewHplb.setVisible(true);
                viewEmaillb.setVisible(true);
            }
        });

        editNamelb = new Label("edit Name: ");
        editNametf = new TextField(20);
        editHplb = new Label("edit Hp: ");
        editHptf = new TextField(20);
        editEmaillb = new Label("edit Email");
        editEmailtf = new TextField(20);
        editbtn = new Button("update");

        editNamelb.setVisible(false);
        editNametf.setVisible(false);
        editHplb.setVisible(false);
        editHptf.setVisible(false);
        editEmaillb.setVisible(false);
        editEmailtf.setVisible(false);
        editbtn.setVisible(false);

        add(editNamelb);
        add(editNametf);
        add(editHplb);
        add(editHptf);
        add(editEmaillb);
        add(editEmailtf);
        add(editbtn);


        menuUpdatebtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible();

                editNamelb.setVisible(true);
                editNametf.setVisible(true);
                editHplb.setVisible(true);
                editHptf.setVisible(true);
                editEmaillb.setVisible(true);
                editEmailtf.setVisible(true);
                editbtn.setVisible(true);

            }
        });

        editbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible();
            }
        });


        delNamelb = new Label("������ �̸� �Է�");
        delNametf = new TextField(20);
        delbtn = new Button("����");
        delNamelb.setVisible(false);
        delNametf.setVisible(false);
        delbtn.setVisible(false);
        add(delNamelb);
        add(delNametf);
        add(delbtn);

        menuDeletebtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible();
                System.out.println("test");

                delNamelb.setVisible(true);
                delNametf.setVisible(true);
                delbtn.setVisible(true);
            }
        });

        delbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible();
                System.out.println("������ư ����");
                new DialogFrame(delbtn);
            }
        });
    }


    public List getListBox() {

        return listBox;
    }

    public void setListBox(List listBox) {
        this.listBox = listBox;
    }

    public void setVisible() {
        insertNamelb.setVisible(false);
        insertHplb.setVisible(false);
        insertEmaillb.setVisible(false);
        insertNametf.setVisible(false);
        insertHptf.setVisible(false);
        insertEmailtf.setVisible(false);
        insertInsertbtn.setVisible(false);

        viewIdlb.setVisible(false);
        viewNamelb.setVisible(false);
        viewHplb.setVisible(false);
        viewEmaillb.setVisible(false);

        listBox.setVisible(false);

        updateNamelb.setVisible(false);
        updateaSearchtf.setVisible(false);
        updateSearchbtn.setVisible(false);
        updateSearchListBox.setVisible(false);

        editNamelb.setVisible(false);
        editNametf.setVisible(false);
        editHplb.setVisible(false);
        editHptf.setVisible(false);
        editEmaillb.setVisible(false);
        editEmailtf.setVisible(false);
        editbtn.setVisible(false);

        delNamelb.setVisible(false);
        delNametf.setVisible(false);
        delbtn.setVisible(false);


    }
}

class DialogFrame extends Frame {
    private Button button;
    private Dialog dialog;

    public DialogFrame(Button button, Button button1) {
        this.button = button1;
        setBounds(100, 100, 450, 300);
        setLayout(new FlowLayout());
        setVisible(true);

        button = new Button("�����ϱ�");
        add(button);

        dialog = new Dialog(this, "�����ϱ�", true);
        dialog.setBounds(100, 100, 450, 300);
        dialog.setVisible(true);

    }

    public DialogFrame(Button button) {
        this.button = button;
    }

    public DialogFrame() {

    }

    public Button getButton() {
        return button;
    }
    public Dialog getDialog() {
        return dialog;
    }
}

