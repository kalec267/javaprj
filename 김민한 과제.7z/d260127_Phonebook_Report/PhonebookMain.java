package d260127_Phonebook_Report;

public class PhonebookMain {
    public static void main(String[] args) {
        new PhonebookFrame();
    }


}
