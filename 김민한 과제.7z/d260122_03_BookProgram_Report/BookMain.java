package d260122_03_BookProgram_Report;

import java.io.IOException;

public class BookMain {
    public static void main(String[] args) throws IOException {
        new BookProgram();
    }
}
